--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(204, 'Vans');

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `store_id`, `brand_id`) VALUES
(1, 122, 56),
(2, 132, 64),
(3, 142, 72),
(4, 143, 73),
(5, 144, 73),
(6, 155, 82),
(7, 156, 83),
(8, 157, 83),
(9, 167, 91),
(10, 168, 92),
(11, 169, 92),
(12, 180, 101),
(13, 181, 102),
(14, 182, 102),
(15, 192, 103),
(16, 193, 111),
(17, 194, 112),
(18, 195, 112),
(19, 205, 113),
(20, 206, 121),
(21, 207, 122),
(22, 208, 122),
(23, 218, 123),
(24, 219, 131),
(25, 220, 132),
(26, 221, 132),
(27, 231, 133),
(28, 232, 141),
(29, 233, 142),
(30, 234, 142),
(31, 244, 143),
(32, 245, 152),
(33, 246, 153),
(34, 247, 153),
(35, 248, 161),
(36, 249, 162),
(37, 250, 162),
(38, 251, 171),
(39, 252, 172),
(40, 253, 172),
(41, 254, 181),
(42, 255, 182),
(43, 256, 182),
(44, 267, 191),
(45, 268, 192),
(46, 269, 192),
(47, 279, 193),
(48, 280, 202),
(49, 281, 203),
(50, 282, 203),
(51, 292, 204);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=293;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
