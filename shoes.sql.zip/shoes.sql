--
-- Database: `shoes`
--
CREATE DATABASE IF NOT EXISTS `shoes` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(58, 'Nike'),
(59, 'Adidas'),
(60, 'Vans'),
(61, 'Reebok');

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `store_id`, `brand_id`) VALUES
(79, 53, 38),
(80, 54, 38),
(81, 53, 38),
(82, 53, 39),
(83, 54, 39),
(84, 53, 39),
(85, 53, 40),
(86, 53, 41),
(87, 53, 41),
(88, 53, 41),
(89, 53, 42),
(90, 54, 42),
(91, 53, 43),
(92, 53, 44),
(93, 54, 44),
(94, 54, 43),
(95, 57, 45),
(96, 56, 45),
(97, 57, 46),
(98, 56, 46),
(99, 57, 47),
(100, 56, 48),
(101, 57, 48),
(102, 56, 49),
(103, 56, 50),
(104, 69, 51),
(105, 70, 52),
(106, 71, 52),
(107, 72, 53),
(108, 72, 54),
(109, 73, 53),
(110, 73, 55),
(111, 72, 56),
(112, 72, 57),
(113, 75, 55),
(114, 75, 56),
(115, 73, 57),
(116, 75, 57),
(117, 75, 57),
(118, 73, 53),
(119, 75, 53),
(120, 76, 53),
(121, 76, 53),
(122, 76, 53),
(123, 77, 53),
(124, 77, 53),
(125, 78, 53),
(126, 78, 54),
(127, 80, 58),
(128, 80, 59),
(129, 80, 60),
(130, 78, 60),
(131, 79, 61),
(132, 79, 60),
(133, 81, 60);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `name`) VALUES
(78, 'Torrences shoe barn'),
(79, 'Nics haus of shoes'),
(80, 'Footlocker'),
(81, 'Vans Store');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
